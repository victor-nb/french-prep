# TCF Canada — Examen blanc (Expression Orale)

Paquet autonome pour faire passer un **examen blanc** des 3 tâches de l'Expression Orale du TCF Canada, avec Claude comme **examinateur**.

## Contenu

```
.claude/skills/tcf-examen-blanc/SKILL.md   ← la skill (instructions de l'examinateur)
tache1/tache1.md                            ← fiche méthode Tâche 1 (présentation)
tache2/tache2.md                            ← fiche méthode Tâche 2 (interaction)
tache2/pick.py                              ← tire une consigne T2 au hasard
tache2/data/corpus.txt                      ← banque de 230 consignes T2 (réelles 2026)
tache3/0-tache3.md … 7-….md                 ← fiches méthode Tâche 3 (point de vue)
tache3/pick.py                              ← tire un sujet T3 au hasard
tache3/data/corpus.txt                      ← banque de 700+ sujets T3 (réels 2022-2026)
```

## Utilisation

1. Décompressez l'archive et placez-vous (le terminal / l'agent) **à la racine** du dossier décompressé (celui qui contient `.claude/`, `tache1/`, `tache2/`, `tache3/`).
2. Lancez la skill : **`/tcf-examen-blanc`** (ou demandez à Claude « fais-moi passer un examen blanc du TCF »).
3. Claude joue l'examinateur : Tâche 1 (présentation, avec interruptions) → Tâche 2 (2 min de prépa puis interaction) → Tâche 3 (monologue ~4 min 30), puis donne un **bilan évaluatif** (points forts/faibles + niveau estimé).

Les sujets sont tirés au hasard via :
```
python3 tache2/pick.py     # une consigne Tâche 2
python3 tache3/pick.py     # un sujet Tâche 3
```

> Les durées de chronométrage suivent un réglage d'entraînement (T1 ~1 min 30, T2 2 min prépa + 2 min 30, T3 4 min 30), légèrement différent du barème officiel — voir la skill pour les ajuster.
